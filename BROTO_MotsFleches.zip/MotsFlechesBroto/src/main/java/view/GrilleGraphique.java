package view;

import model.*;
import objects.*;
import org.jetbrains.annotations.NotNull;

import enumerations.Directions;
import enumerations.CheckCase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.EventListener;
import java.util.Objects;

public class GrilleGraphique{

    private static JFrame frame;
    private static JTextField field;
    private static JPanel contentPanel;
    private static JPanel displayPanel;
    private static JPanel buttonPanel;
    private static boolean start = true;
    private static double result = 0;
    private static String lastCommand = "=";
    private static JPopupMenu menuContextuel;


    protected JButton[][] grilleDeBouton;
    private final Grille grille;

    public GrilleGraphique(Grille grille) {

        JFrame.setDefaultLookAndFeelDecorated(true);

        this.grille = grille;
        this.grilleDeBouton = new JButton[grille.getH()][grille.getL()];


        frame = new JFrame("Mots fleches");
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(grille.getH(), grille.getL()));


        frame.setSize(grille.getL() * 120, grille.getH() * 120);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);



        for (int lg = 0; lg < grille.getL(); lg++) {
            for (int ht = 0; ht < grille.getH(); ht++) {

                String sLabel = "";

                JButton btn = this.buttonFactory(this, sLabel, lg * 40, ht * 40, lg, ht);
                grilleDeBouton[ht][lg] = btn;
                panel.add(btn);
            }
        }


        frame.add(panel);

        frame.setVisible(true);

    }

    public void displayGrille() {

        String sLabel;

        JLabel arrowLabel;
        JButton jButtonTemp;
        Directions directionDefTemp = null;
        Directions directionDefTemp_1 = null;
        Directions directionDefTemp_2 = null;
        String imageName = "";

        for (int lg = 0; lg < grille.getL(); lg++) {
            for (int ht = 0; ht < grille.getH(); ht++) {
                jButtonTemp = grilleDeBouton[lg][ht];
                if (this.grille.getTableauDeCases()[lg][ht] instanceof CaseLettre) {
                    sLabel = ((CaseLettre) this.grille.getTableauDeCases()[lg][ht]).getLettreString();
                    jButtonTemp.setBorderPainted(true);
                    jButtonTemp.setFocusPainted(true);
                    jButtonTemp.setContentAreaFilled(true);
                    grilleDeBouton[lg][ht] = jButtonTemp;
                }
                else if (this.grille.getTableauDeCases()[lg][ht] instanceof CaseDefinition caseDefinition) {
                    sLabel = caseDefinition.definition;
                    directionDefTemp = caseDefinition.direction;

                    switch (directionDefTemp) {
                        case VERTICALDIRECT -> {
                            imageName = "arrow_straight_down.png";
                        }
                        case HORIZONTALDIRECT -> {
                            imageName = "arrow_straight_right.png";
                        }
                        case VERTICALINDIRECT -> {
                            imageName = "arrow_right_downward.png";
                        }
                        case HORIZONTALINDIRECT -> {
                            imageName = "arrow_bottom_right";
                        }
                    }

                    jButtonTemp = grilleDeBouton[lg][ht];


                    ImageIcon imageIcon = new ImageIcon("images/" + imageName);

                    Image scaledImage = null;

                    switch (directionDefTemp) {
                        case VERTICALDIRECT, HORIZONTALDIRECT -> {
                            scaledImage = imageIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH) ;
                        }
                        case VERTICALINDIRECT, HORIZONTALINDIRECT -> {
                            scaledImage = imageIcon.getImage().getScaledInstance(70, 30, Image.SCALE_SMOOTH) ;
                        }
                    }

                    imageIcon = new ImageIcon(scaledImage);
                    arrowLabel = new JLabel(imageIcon);
                    arrowLabel.setLocation(lg*40 + 500, ht* 40);
                    jButtonTemp.add(arrowLabel);
                    jButtonTemp.setBorderPainted(false);
                    jButtonTemp.setFocusPainted(false);
                    jButtonTemp.setContentAreaFilled(false);
                    grilleDeBouton[lg][ht] = jButtonTemp;

                }
                else if (this.grille.getTableauDeCases()[lg][ht] instanceof CasePlusieursDefinitions caseDefinitionMultiple) {
                    sLabel = "<html>" + caseDefinitionMultiple.definition_1 + "<br /><br />" + caseDefinitionMultiple.definition_2 + "</html>";
                    directionDefTemp_1 = caseDefinitionMultiple.direction_1;
                    directionDefTemp_2 = caseDefinitionMultiple.direction_2;

                    switch (directionDefTemp_1) {
                        case VERTICALDIRECT -> {
                            imageName = "arrow_straight_down.png";
                        }
                        case HORIZONTALDIRECT -> {
                            imageName = "arrow_straight_right.png";
                        }
                        case VERTICALINDIRECT -> {
                            imageName = "arrow_right_downward.png";
                        }
                        case HORIZONTALINDIRECT -> {
                            imageName = "arrow_bottom_right";
                        }
                    }
                    jButtonTemp = grilleDeBouton[lg][ht];
                    ImageIcon imageIcon = new ImageIcon("images/" + imageName);
                    Image scaledImage = null;
                    switch (directionDefTemp_1) {
                        case VERTICALDIRECT, HORIZONTALDIRECT -> {
                            scaledImage = imageIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH) ;
                        }
                        case VERTICALINDIRECT, HORIZONTALINDIRECT -> {
                            scaledImage = imageIcon.getImage().getScaledInstance(70, 30, Image.SCALE_SMOOTH) ;
                        }
                    }
                    imageIcon = new ImageIcon(scaledImage);
                    arrowLabel = new JLabel(imageIcon);

                    jButtonTemp.setBorderPainted(false);
                    jButtonTemp.setFocusPainted(false);
                    jButtonTemp.setContentAreaFilled(false);
                    jButtonTemp.add(arrowLabel);


                    switch (directionDefTemp_2) {
                        case VERTICALDIRECT -> {
                            imageName = "arrow_straight_down.png";
                        }
                        case HORIZONTALDIRECT -> {
                            imageName = "arrow_straight_right.png";
                        }
                        case VERTICALINDIRECT -> {
                            imageName = "arrow_right_downward.png";
                        }
                        case HORIZONTALINDIRECT -> {
                            imageName = "arrow_bottom_right";
                        }
                    }
                    jButtonTemp = grilleDeBouton[lg][ht];
                    imageIcon = new ImageIcon("images/" + imageName);
                    scaledImage = null;
                    switch (directionDefTemp_2) {
                        case VERTICALDIRECT, HORIZONTALDIRECT -> {
                            scaledImage = imageIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH) ;
                        }
                        case VERTICALINDIRECT, HORIZONTALINDIRECT -> {
                            scaledImage = imageIcon.getImage().getScaledInstance(70, 30, Image.SCALE_SMOOTH) ;
                        }
                    }
                    imageIcon = new ImageIcon(scaledImage);
                    arrowLabel = new JLabel(imageIcon);

                    jButtonTemp.setBorderPainted(false);
                    jButtonTemp.setFocusPainted(false);
                    jButtonTemp.setContentAreaFilled(false);
                    jButtonTemp.add(arrowLabel);
                    arrowLabel.setLocation(lg*40, ht* 40);

                    grilleDeBouton[lg][ht] = jButtonTemp;

                }
                else if (this.grille.getTableauDeCases()[lg][ht] instanceof CaseVide) {
                    sLabel = "";
                    jButtonTemp.setBorderPainted(true);
                    jButtonTemp.setFocusPainted(true);
                    jButtonTemp.setContentAreaFilled(true);
                    grilleDeBouton[lg][ht] = jButtonTemp;
                }
                else {
                    sLabel = "XX";
                    jButtonTemp.setBorderPainted(true);
                    jButtonTemp.setFocusPainted(true);
                    jButtonTemp.setContentAreaFilled(true);
                    grilleDeBouton[lg][ht] = jButtonTemp;
                }

                grilleDeBouton[lg][ht].setText(sLabel);

            }
        }
    }


    private static JLabel labelFactory(String text, int x, int y) {

        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setAlignmentX(SwingConstants.CENTER);
        label.setAlignmentY(SwingConstants.CENTER);
        label.setBounds(x, y, 35, 35);
        label.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        label.setFocusable(true);

        return label;
    }

    private @NotNull JButton buttonFactory(GrilleGraphique grille, String text, int sizeX, int sizeY, int caseX, int caseY) {

        JButton btn = new JButton(text);
        btn.setAlignmentX(SwingConstants.CENTER);
        btn.setAlignmentY(SwingConstants.CENTER);
        btn.setSize(sizeX, sizeY);
        btn.setBounds(sizeX, sizeY, 35, 35);
        btn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        btn.setFocusable(false);
        Case[][] grilleTemp = this.grille.getTableauDeCases();
        btn.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                JPopupMenu varJPopupMenu = new JPopupMenu();
                System.out.printf("Je suis en " + caseY + ":" + caseX);
                Case laCase = grilleTemp[caseY][caseX];

                if (e.getButton() == MouseEvent.BUTTON1 && laCase instanceof CaseVide caseTemp) {
                    String lettreTemp = null;
                    boolean inputIsCorrect = false;
                    while (!inputIsCorrect) {
                        lettreTemp = JOptionPane.showInputDialog("Saisissez une lettre");
                        if (lettreTemp.length() == 1) {
                            inputIsCorrect = true;
                        }
                    }
                    grille.grille.setCaseAt(new CaseLettre(new Coordonnees(caseY, caseX), lettreTemp.charAt(0)), new Coordonnees(caseY, caseX));
                    displayGrille();


                } else {
                    if (laCase instanceof CaseVide) {
                        varJPopupMenu = createContextualMenu(CheckCase.CASE_VIDE, laCase, caseX, caseY);
                    } else if (laCase instanceof CaseLettre) {
                        varJPopupMenu = createContextualMenu(CheckCase.CASE_LETTRE, laCase, caseX, caseY);
                    } else if (laCase instanceof CaseDefinition) {
                        varJPopupMenu = createContextualMenu(CheckCase.CASE_DEFINITION, laCase, caseX, caseY);
                    } else {
                        varJPopupMenu = createContextualMenu(CheckCase.CASE_DEFINITION_MULTIPLE, laCase, caseX, caseY);
                    }
                }



                menuContextuel = varJPopupMenu;
                menuContextuel.show(e.getComponent(), e.getX(), e.getY());



            }
        });

        return btn;
    }

    private JPopupMenu createContextualMenu(CheckCase enumCase, Case uneCase, int x, int y) {
        JPopupMenu jPopupMenu = new JPopupMenu();
        Coordonnees coordonneeCase = new Coordonnees(y, x);

        JMenuItem ajouteMotVertical = new JMenuItem("Ajouter un mot vertical");
        ajouteMotVertical.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String mot = JOptionPane.showInputDialog(frame, "Saisissez votre mot");
                grille.ajouteMotVertical(mot, coordonneeCase.x, coordonneeCase.y);
                System.out.println("ajouter mot Vertical");
                displayGrille();
            }
        });

        JMenuItem ajouteMotHorizontal = new JMenuItem("Ajouter un mot horizontal");
        ajouteMotHorizontal.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String mot = JOptionPane.showInputDialog(frame, "Saisissez votre mot");
                grille.ajouteMotHorizontal(mot, coordonneeCase.x, coordonneeCase.y);
                System.out.println("Ajouter mot Horizontal");
                displayGrille();
            }
        });

        JMenuItem ajouterDef = new JMenuItem("Ajouter une definition");
        ajouterDef.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {


                String definitionTemp = JOptionPane.showInputDialog(frame, "Saisissez votre définition");

                Directions direction = showDialogDirection();
                grille.setCaseAt(new CaseDefinition(coordonneeCase, definitionTemp, direction), coordonneeCase);
                System.out.println("ajouter def");
                displayGrille();
            }
        });

        JMenuItem ajouterDefMultiple = new JMenuItem("Ajouter une deuxième definition");
        ajouterDefMultiple.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String definitionTemp = JOptionPane.showInputDialog(frame, "Saisissez votre definition");
                CaseDefinition uneCaseDefTemp = (CaseDefinition)uneCase;

                Directions direction = showDialogDirection();

                grille.fromSimpleToDoubleDefinition(uneCaseDefTemp, coordonneeCase, definitionTemp, direction);

                System.out.println("Ajouter deuxième definition");
                displayGrille();
            }
        });

        JMenuItem supprimerDef = new JMenuItem("Supprimer la definition");
        supprimerDef.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                grille.SupprCase(coordonneeCase);
                System.out.println("Supprimer definition");
                displayGrille();
            }
        });

        JMenuItem supprimerLettre = new JMenuItem("Supprimer la lettre");
        supprimerLettre.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                grille.SupprCase(coordonneeCase);
                displayGrille();
                System.out.println("Supprimer case");
            }
        });

        JMenuItem trouver_un_mot = new JMenuItem("Trouver un mot");
        trouver_un_mot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String[] direction = new String[] {"Horizontal", "Vertical"};
                JComboBox comboDirectionMot = new JComboBox(direction);

                JFrame.setDefaultLookAndFeelDecorated(true);
                JFrame framePopUp = new JFrame("CustomComboBoxDemo");

                String[] options = {"Ok", "Annuler"};

                int selection = JOptionPane.showOptionDialog(frame, comboDirectionMot, "Mots", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options,
                        options[0]);

                if (selection > 0) {
                    System.out.println("Selection : " + options[selection]);
                }

                String directionChoisie = comboDirectionMot.getSelectedItem().toString();

                ArrayList<String> words = new ArrayList<String>();

                String motChoisi;

                if (Objects.equals(directionChoisie, "Horizontal")) {
                    words = grille.findWord(coordonneeCase.x, coordonneeCase.y, Directions.HORIZONTALDIRECT);
                    motChoisi = showRegexWord(words);
                    grille.ajouteMotHorizontal(motChoisi,  coordonneeCase.x, y);
                } else {
                    words = grille.findWord( coordonneeCase.x, coordonneeCase.y, Directions.VERTICALDIRECT);
                    motChoisi = showRegexWord(words);
                    grille.ajouteMotVertical(motChoisi,  coordonneeCase.x,  coordonneeCase.y);
                }


                displayGrille();
                System.out.println("Supprimer case");
            }
        });


        if (enumCase == CheckCase.CASE_VIDE) {
            jPopupMenu.add(ajouterDef);
            jPopupMenu.add(ajouteMotVertical);
            jPopupMenu.add(ajouteMotHorizontal);
            jPopupMenu.add(trouver_un_mot);
        } else if (enumCase == CheckCase.CASE_LETTRE) {
            jPopupMenu.add(supprimerLettre);
        } else if (enumCase == CheckCase.CASE_DEFINITION) {
            jPopupMenu.add(supprimerDef);
            jPopupMenu.add(ajouterDefMultiple);
        } else if (enumCase == CheckCase.CASE_DEFINITION_MULTIPLE) {
            jPopupMenu.add(supprimerDef);
        }

        return jPopupMenu;
    }

    public String showRegexWord(ArrayList<String> mots) {

        JComboBox comboMots = new JComboBox(mots.toArray());

        JFrame.setDefaultLookAndFeelDecorated(true);

        JFrame framePopUp = new JFrame("CustomComboBoxDemo");

        String[] options = {"Ok", "Annuler"};

        int selection = JOptionPane.showOptionDialog(frame, comboMots, "Mots", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options,
                options[0]);

        if (selection > 0) {
            System.out.println("Selection : " + options[selection]);
        }

        Object directionSelected = comboMots.getSelectedItem();
        return directionSelected.toString();
    }

    public Directions showDialogDirection() {

        Directions direction = null;
        ImageIcon[] images;
        String[] imageName = new String[] {"arrow_bottom_right.png", "arrow_straight_down.png", "arrow_straight_right.png", "arrow_right_downward.png"};
        String[] descriptions = new String[] {"HI", "VD","HD","VI"};


        JComboBox comboDirection = new JComboBox();


        images = new ImageIcon[descriptions.length];
        for (int i = 0; i < imageName.length; i++) {
            ImageIcon imageIcon = new ImageIcon("images/" + imageName[i]);
            Image scaledImage = imageIcon.getImage().getScaledInstance(50, 100, Image.SCALE_SMOOTH) ;

            imageIcon = new ImageIcon(scaledImage);
            images[i] = imageIcon;

            if (images[i] != null) {
                images[i].setDescription(descriptions[i]);
            }

            comboDirection.addItem(images[i]);
        }
        comboDirection.setMaximumRowCount(4);

        JFrame.setDefaultLookAndFeelDecorated(true);

        JFrame framePopUp = new JFrame("CustomComboBoxDemo");

        String[] options = {"Ok", "Annuler"};

        int selection = JOptionPane.showOptionDialog(frame, comboDirection, "Direction", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options,
                options[0]);

        if (selection > 0) {
            System.out.println("Selection : " + options[selection]);
        }

        Object directionSelected = comboDirection.getSelectedItem();

        if ("VD".equals(directionSelected.toString())) {
            return Directions.VERTICALDIRECT;
        } else if ("VI".equals(directionSelected.toString())) {
            return Directions.VERTICALINDIRECT;
        } else if ("HD".equals(directionSelected.toString())) {
            return Directions.HORIZONTALDIRECT;
        } else if ("HI".equals(directionSelected.toString())) {
            return Directions.HORIZONTALINDIRECT;
        }
        
        return direction;
    }


}
