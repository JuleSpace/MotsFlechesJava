package objects;

public abstract class Case {

     protected Coordonnees coordonnee;

     public Case() {}
     public Coordonnees getCoordonnee() {
          return this.coordonnee;
     }

     /**
      * Permet de donner des coordonnées à une case sans créer d'objet Coordonnee
      * @param x
      * @param y
      */
     public void setCoordonnee(int x, int y) {
          this.coordonnee = new Coordonnees(x, y);
     }

     public int getx() {
          return this.coordonnee.x;
     }

     public int gety() {
          return this.coordonnee.y;
     }

}
