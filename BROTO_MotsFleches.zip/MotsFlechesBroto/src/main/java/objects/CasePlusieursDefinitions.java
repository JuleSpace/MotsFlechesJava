package objects;

import enumerations.Directions;

public class CasePlusieursDefinitions extends Case {

    public Directions direction_1;
    public Directions direction_2;
    public Coordonnees coordonneeDef;
    public String definition_1;
    public String definition_2;
    public Mot mot_1;
    public Mot mot_2;

    public CasePlusieursDefinitions() {}
    public CasePlusieursDefinitions(Coordonnees coordonneeDef) {
        this.coordonneeDef = coordonneeDef;
    }

    public CasePlusieursDefinitions(Coordonnees coordonneeDef, String definition_1, String definition_2) {
        this.coordonneeDef = coordonneeDef;
        this.definition_1 = definition_1;
        this.definition_2 = definition_2;

    }
    public CasePlusieursDefinitions(Coordonnees coordonneeDef, String definition_1, String definition_2, Directions direction_1, Directions direction_2) {
        this.coordonneeDef = coordonneeDef;
        this.definition_1 = definition_1;
        this.definition_2 = definition_2;
        this.direction_1 = direction_1;
        this.direction_2 = direction_2;
    }


}
