package objects;

import enumerations.Directions;

public class CaseDefinition extends Case {

    public Directions direction;
    Coordonnees coordonnee;
    public String definition;
    public Mot mot;

    public CaseDefinition() {}
    public CaseDefinition(String definition) {
        this.definition = definition;
    }
    public CaseDefinition(Coordonnees coordonnee, String definition) {
        this.coordonnee = coordonnee;
        this.definition = definition;
    }

    public CaseDefinition(Coordonnees coordonnee, String definition, Directions direction) {
        this.coordonnee = coordonnee;
        this.definition = definition;
        this.direction = direction;
    }

    public CaseDefinition(Coordonnees coordonnee, String definition, Directions direction, Mot mot) {
        this.coordonnee = coordonnee;
        this.definition = definition;
        this.direction = direction;
        this.mot = mot;
    }


}
