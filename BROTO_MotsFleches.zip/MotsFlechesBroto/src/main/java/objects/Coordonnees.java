package objects;

public class Coordonnees {

    public int x;
    public int y;

    public Coordonnees() {}
    public Coordonnees(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
