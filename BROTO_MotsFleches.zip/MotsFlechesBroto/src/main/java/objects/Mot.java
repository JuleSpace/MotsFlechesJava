package objects;

public class Mot {

    private String mot;
    private boolean isVertical;
    private Coordonnees coordonneeDepartMot;



    public Mot(String mot, Coordonnees coordonneeDepartMot, boolean isVertical) {
        this.mot = mot;
        this.coordonneeDepartMot = coordonneeDepartMot;
        this.isVertical = isVertical;
    }

    public Coordonnees getCoordonneeDepartMot() { return this.coordonneeDepartMot; }

}
