package objects;

public class CaseVide extends Case {

    Coordonnees coordonneeDef;

    public CaseVide() {}
    public CaseVide(Coordonnees coordonneeDef) {
        this.coordonneeDef = coordonneeDef;
    }

}
