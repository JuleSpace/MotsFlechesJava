package enumerations;

import objects.Case;
import objects.CaseDefinition;
import objects.CasePlusieursDefinitions;
import objects.CaseLettre;

public enum CheckCase {
    CASE_VIDE,
    CASE_LETTRE,
    CASE_DEFINITION,
    CASE_DEFINITION_MULTIPLE;

    public static CheckCase getClassEnum(Case uneCase) {
        if (uneCase instanceof CaseLettre) return CheckCase.CASE_LETTRE;
        else if (uneCase instanceof CaseDefinition) return CheckCase.CASE_DEFINITION;
        else if (uneCase instanceof CasePlusieursDefinitions) return CheckCase.CASE_DEFINITION_MULTIPLE;
        else return CheckCase.CASE_VIDE;
    }

}
