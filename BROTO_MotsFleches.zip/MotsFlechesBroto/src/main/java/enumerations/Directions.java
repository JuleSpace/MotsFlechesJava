package enumerations;

public enum Directions {
    VERTICALDIRECT,
    HORIZONTALDIRECT,
    VERTICALINDIRECT,
    HORIZONTALINDIRECT,
}
