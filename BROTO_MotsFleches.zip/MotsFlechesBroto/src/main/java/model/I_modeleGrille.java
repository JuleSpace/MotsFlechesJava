package model;

import objects.Case;

public interface I_modeleGrille {
    public boolean ajouteMotHorizontal(String string, int x, int y);
    public boolean ajouteMotVertical(String string, int x, int y);
    public int getH();
    public int getL();
    public Case[][] getTableauDeCases();
}
