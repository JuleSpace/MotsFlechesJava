package controleur;

import model.Grille;
import view.GrilleGraphique;

public class GrilleControleur {

    private GrilleGraphique grilleGraphique;
    private Grille grille;

    public GrilleControleur(Grille grille, GrilleGraphique grilleGraphique) {
        this.grille = grille;
        this.grilleGraphique = grilleGraphique;
    }


}
