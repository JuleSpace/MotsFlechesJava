import model.Grille;
import view.GrilleGraphique;

import controleur.GrilleControleur;
import enumerations.Directions;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class MainApp {

    public static void main(String args[]) throws IOException {

        Grille grille;
        GrilleControleur grilleControleur;
        GrilleGraphique grilleGraphique;

        grille = new Grille();
        grille.initGrille(6, 6);
        grilleGraphique = new GrilleGraphique(grille);
        grilleControleur = new GrilleControleur(grille, grilleGraphique);
        grilleGraphique.displayGrille();

    }
}
