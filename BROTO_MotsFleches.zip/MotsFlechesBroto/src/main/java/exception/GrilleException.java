package exception;

public class GrilleException extends Exception{
}
